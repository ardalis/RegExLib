using System;

namespace RegExLib.Web.UI.Controls
{
	/// <summary>
    /// Summary description for LQButtonControl.
	/// </summary>
    public class LQButtonControl : LQBaseAdControl
	{
        public LQButtonControl()
        {
            base.Format = 16;
        }
	}
}
