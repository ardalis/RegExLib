using System;

namespace RegExLib.Web.UI.Controls
{
    /// <summary>
    /// Summary description for LQBannerControl.
    /// </summary>
    public class LQBannerControl : LQBaseAdControl
    {
        public LQBannerControl()
        {
            base.Format = 1;
        }
    }
}
