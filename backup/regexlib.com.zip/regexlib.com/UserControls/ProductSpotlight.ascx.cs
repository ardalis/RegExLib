using System;

namespace RegExLib.Web.UserControls {
    public partial class ProductSpotlight : System.Web.UI.UserControl { }
}