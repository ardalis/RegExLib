using System;

namespace RegExLib.Web.UserControls {
    public partial class TopContributors : System.Web.UI.UserControl { }
}