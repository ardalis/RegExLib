using System;

namespace RegExLib.Web.UserControls {
    public partial class HostingSpotlight : System.Web.UI.UserControl { }
}