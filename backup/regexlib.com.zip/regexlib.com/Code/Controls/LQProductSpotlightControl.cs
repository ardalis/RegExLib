using System;

namespace RegExLib.Web.UI.Controls
{
	/// <summary>
    /// Summary description for LQProductSpotlightControl.
	/// </summary>
    public class LQProductSpotlightControl : LQBaseAdControl
	{
        public LQProductSpotlightControl()
        {
            base.Format = 2;
        }
	}
}
