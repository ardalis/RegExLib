using System;

namespace RegExLib.Web.UI.Controls
{
    /// <summary>
    /// Summary description for LQLeaderboardControl.
    /// </summary>
    public class LQLeaderboardControl : LQBaseAdControl
    {
        public LQLeaderboardControl()
        {
            base.Format = 8;
        }
    }
}
