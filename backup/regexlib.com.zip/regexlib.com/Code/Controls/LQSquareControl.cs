using System;

namespace RegExLib.Web.UI.Controls
{
    /// <summary>
    /// Summary description for LQSquareControl.
    /// </summary>
    public class LQSquareControl : LQBaseAdControl
    {
        public LQSquareControl()
        {
            base.Format = 5;
        }
    }
}
