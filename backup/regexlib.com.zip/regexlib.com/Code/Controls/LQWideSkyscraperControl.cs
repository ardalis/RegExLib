using System;

namespace RegExLib.Web.UI.Controls
{
    /// <summary>
    /// Summary description for LQWideSkyscraperControl.
    /// </summary>
    public class LQWideSkyscraperControl : LQBaseAdControl
    {
        public LQWideSkyscraperControl()
        {
            base.Format = 18;
        }
    }
}
