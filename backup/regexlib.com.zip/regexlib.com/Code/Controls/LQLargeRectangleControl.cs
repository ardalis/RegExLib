using System;

namespace RegExLib.Web.UI.Controls
{
    /// <summary>
    /// Summary description for LQLargeRectangleControl.
    /// </summary>
    public class LQLargeRectangleControl : LQBaseAdControl
    {
        public LQLargeRectangleControl()
        {
            base.Format = 7;
        }
    }
}
