using System;

namespace RegExLib.Web.UI.Controls
{
	/// <summary>
    /// Summary description for LQHostingSpotlightControl.
	/// </summary>
    public class LQHostingSpotlightControl : LQBaseAdControl
	{
        public LQHostingSpotlightControl()
        {
            base.Format = 3;
        }
	}
}
