using System;

namespace RegExLib.Web.UI.Controls
{
    /// <summary>
    /// Summary description for LQSkyscraperControl.
    /// </summary>
    public class LQSkyscraperControl : LQBaseAdControl
    {
        public LQSkyscraperControl()
        {
            base.Format = 4;
        }
    }
}
